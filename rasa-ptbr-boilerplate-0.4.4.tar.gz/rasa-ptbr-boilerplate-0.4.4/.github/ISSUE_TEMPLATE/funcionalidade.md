---
name: Funcionalidade
about: Sugerir uma ideia para o projeto
title: ''
labels: evolucao
assignees: ''

---

**A sua sugestão de funcionalidade está relacionada a um problema? Descreva**

**Descreva a solução desejada**

**Tarefas:**
- [ ]
