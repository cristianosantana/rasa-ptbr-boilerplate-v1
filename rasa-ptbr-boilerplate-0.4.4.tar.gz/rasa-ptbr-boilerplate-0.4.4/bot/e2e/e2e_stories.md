## end-to-end story 1
* cumprimentar: oi
   - utter_cumprimentar
* action_test: test custom action
   - action_test

## end-to-end story 2
* cumprimentar: oi
   - utter_cumprimentar
* time: que time vc torce?
   - utter_time
* negar: não
   - utter_despedir

## end-to-end story 3
* tudo_bem: tudo bem?
   - utter_tudo_bem
* bff: quem é seu best friend?
   - utter_bff
* negar: não
   - utter_despedir

## end-to-end story 4
* o_que_sei_falar: me ajuda
   - utter_o_que_sei_falar
* despedir: tchau
   - utter_despedir

## end-to-end story 5
* cumprimentar: Oi
   - utter_cumprimentar
* license: posso copiar voce
   - utter_license
* diga_mais: como funciona?
   - utter_diga_mais
* despedir: até mais
   - utter_despedir

## end-to-end story 6
* playlist: me indica uma música?
   - utter_playlist
* negar: não
   - utter_despedir

## end-to-end story 7
* comida: qual comida você me sugere?
   - utter_comida
* negar: não
   - utter_despedir

## end-to-end story 8
* cumprimentar: Oi
   - utter_cumprimentar
* de_onde_voce_eh: de onde você é?
   - utter_de_onde_voce_eh
* relationship: Gosta de alguém?
   - utter_relationship
* negar: não
   - utter_despedir

## end-to-end story 9
* risada: risos
   - utter_risada
* negar: não
   - utter_despedir