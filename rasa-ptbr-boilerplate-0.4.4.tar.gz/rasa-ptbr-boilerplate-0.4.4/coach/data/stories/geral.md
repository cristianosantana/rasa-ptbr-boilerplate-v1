## cumprimentar
* cumprimentar
    - utter_cumprimentar

## Despedir
* despedir
    - utter_despedir

## Tudo Bem Story
* tudo_bem
    - utter_tudo_bem

## Oi Tudo Bem Story 
* cumprimentar
    - utter_cumprimentar
* tudo_bem
    - utter_tudo_bem

## Nao entendi
* diga_mais
    - utter_diga_mais  

## fallback
* out_of_scope
    - utter_default

## negar sem contexto
* negar
    - utter_despedir

## negar_despedir
* negar_despedir
    - utter_despedir

## elogios 1
* elogios
    - utter_elogios
    - utter_continuar_conversa

## elogios 2
* cumprimentar
    - utter_cumprimentar
* elogios
    - utter_elogios
    - utter_continuar_conversa

## meajuda 1
* o_que_sei_falar
    - utter_o_que_sei_falar

## meajuda 2
* cumprimentar
    - utter_cumprimentar
* o_que_sei_falar
    - utter_o_que_sei_falar

## afirmar_botao
* botao
    - utter_botao
* afirmacao_botao
    - utter_afirmacao_botao

## negar_botao
* botao
    - utter_botao
* negacao_botao
    - utter_negacao_botao
