## path_religiao 1
* religiao
    - utter_religiao
    - utter_continuar_conversa

## path_religiao 2
* cumprimentar
    - utter_cumprimentar
* religiao
    - utter_religiao
    - utter_continuar_conversa

## path_esporte 1
* esporte
    - utter_esporte
    - utter_continuar_conversa

## path_esporte 2
* cumprimentar
    - utter_cumprimentar
* esporte
    - utter_esporte
    - utter_continuar_conversa

## path_time 1
* time
    - utter_time
    - utter_continuar_conversa

## path_time 2
* cumprimentar
    - utter_cumprimentar
* time
    - utter_time
    - utter_continuar_conversa

## path_linguagens 1
* linguagens
    - utter_linguagens
    - utter_continuar_conversa

## path_linguagens 2
* cumprimentar
    - utter_cumprimentar
* linguagens
    - utter_linguagens
    - utter_continuar_conversa

## path_genero 1
* genero
    - utter_genero
    - utter_continuar_conversa

## path_genero 2
* cumprimentar
    - utter_cumprimentar
* genero
    - utter_genero
    - utter_continuar_conversa

## path_star_wars 1
* star_wars
    - utter_star_wars
    - utter_continuar_conversa

## path_star_wars 2
* cumprimentar
    - utter_cumprimentar
* star_wars
    - utter_star_wars
    - utter_continuar_conversa

## path_piada 1
* piada
    - utter_piada
    - utter_continuar_conversa

## path_piada 2
* cumprimentar
    - utter_cumprimentar
* piada
    - utter_piada
    - utter_continuar_conversa

## path_license 1
* license
    - utter_license
    - utter_continuar_conversa

## path_license 2
* cumprimentar
    - utter_cumprimentar
* license
    - utter_license
    - utter_continuar_conversa

## path_onde_voce_mora 1
* onde_voce_mora
    - utter_onde_voce_mora
    - utter_continuar_conversa

## path_onde_voce_mora 2
* cumprimentar
    - utter_cumprimentar
* onde_voce_mora
    - utter_onde_voce_mora
    - utter_continuar_conversa

## path_como_estou 1
* como_estou
    - utter_como_estou
    - utter_continuar_conversa

## path_como_estou 2
* cumprimentar
    - utter_cumprimentar
* como_estou
    - utter_como_estou
    - utter_continuar_conversa

## path_playlist 1
* playlist
    - utter_playlist
    - utter_continuar_conversa

## path_playlist 2
* cumprimentar
    - utter_cumprimentar
* playlist
    - utter_playlist
    - utter_continuar_conversa

## path_comida 1
* comida
    - utter_comida
    - utter_continuar_conversa

## path_comida 2
* cumprimentar
    - utter_cumprimentar
* comida
    - utter_comida
    - utter_continuar_conversa

## path_cor 1
* cor
    - utter_cor
    - utter_continuar_conversa

## path_cor 2
* cumprimentar
    - utter_cumprimentar
* cor
    - utter_cor
    - utter_continuar_conversa

## path_de_onde_voce_eh 1
* de_onde_voce_eh
    - utter_de_onde_voce_eh
    - utter_continuar_conversa

## path_de_onde_voce_eh 2
* cumprimentar
    - utter_cumprimentar
* de_onde_voce_eh
    - utter_de_onde_voce_eh
    - utter_continuar_conversa

## path_relationship 1
* relationship
    - utter_relationship
    - utter_continuar_conversa

## path_relationship 2
* cumprimentar
    - utter_cumprimentar
* relationship
    - utter_relationship
    - utter_continuar_conversa

## path_me 1
* me
    - utter_me
    - utter_continuar_conversa

## path_me 2
* cumprimentar
    - utter_cumprimentar
* me
    - utter_me
    - utter_continuar_conversa

## path_filhos 1
* filhos
    - utter_filhos
    - utter_continuar_conversa

## path_filhos 2
* cumprimentar
    - utter_cumprimentar
* filhos
    - utter_filhos
    - utter_continuar_conversa

## path_filme 1
* filme
    - utter_filme
    - utter_continuar_conversa

## path_filme 2
* cumprimentar
    - utter_cumprimentar
* filme
    - utter_filme
    - utter_continuar_conversa

## path_signo 1
* signo
    - utter_signo
    - utter_continuar_conversa

## path_signo 2
* cumprimentar
    - utter_cumprimentar
* signo
    - utter_signo
    - utter_continuar_conversa

## path_triste 1
* triste
    - utter_triste
    - utter_continuar_conversa

## path_triste 2
* cumprimentar
    - utter_cumprimentar
* triste
    - utter_triste
    - utter_continuar_conversa

## path_hobby 1
* hobby
    - utter_hobby
    - utter_continuar_conversa

## path_hobby 2
* cumprimentar
    - utter_cumprimentar
* hobby
    - utter_hobby
    - utter_continuar_conversa

## path_bff 1
* bff
    - utter_bff
    - utter_continuar_conversa

## path_bff 2
* cumprimentar
    - utter_cumprimentar
* bff
    - utter_bff
    - utter_continuar_conversa

## path_historia 1
* historia
    - utter_historia
    - utter_continuar_conversa

## path_historia 2
* cumprimentar
    - utter_cumprimentar
* historia
    - utter_historia
    - utter_continuar_conversa

## path_risada 1
* risada
    - utter_risada
    - utter_continuar_conversa

## path_risada 2
* cumprimentar
    - utter_cumprimentar
* risada
    - utter_risada
    - utter_continuar_conversa