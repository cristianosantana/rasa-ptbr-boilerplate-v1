### Adicionar bot ao RocketChat

Para configurar o bot no rocketchat, devem ser seguidos os passos a seguir.

- Primeiro você deve clicar no ícone Directory localizado na parte superior esquerda da tela, conforme mostra a imagem a seguir.
<div style="text-align:center; margin-bottom:30px"><img src="https://user-images.githubusercontent.com/18130942/64707710-c8717e80-d489-11e9-9b10-58906d5f7f85.png"/></div>

- A seguir será aberta uma nova tela com os canais existentes. Clique no canal General
<div style="text-align:center; margin-bottom:30px"><img src="https://user-images.githubusercontent.com/18130942/64707839-01a9ee80-d48a-11e9-83c9-d72366649f5c.png"/></div>

- Após isso clique na opção Join
<div style="text-align:center; margin-bottom:30px"><img src="https://user-images.githubusercontent.com/26297247/64720477-f2826b00-d4a0-11e9-8364-1c9531d97931.png"/></div>


-  O canal do bot será exibido nessa tela, clique no nome do bot como indicado na imagem abaixo
<div style="text-align:center; margin-bottom:30px"><img src="https://user-images.githubusercontent.com/26297247/64720725-848a7380-d4a1-11e9-87a9-719cbfee1010.png"/></div>

- Por último clique na opção conversation, que irá redirecionar para o chat do bot
<div style="text-align:center; margin-bottom:30px"><img src="https://user-images.githubusercontent.com/26297247/64720768-9cfa8e00-d4a1-11e9-9b2e-cb8772742a33.png"/></div>

- Agora basta conversar com @ FAMOOS@!
